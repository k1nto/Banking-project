﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.Entity.Validation;

namespace Course_project
{
    public partial class newAccount : Form
    {
        string gender = string.Empty;
        string m_status = string.Empty;
        decimal no;
        banking_dbEntities2 BSE;
        MemoryStream ms;

        public newAccount()
        {
            InitializeComponent();
            loaddate();
            loadaccount();
            loadstate();
        }

        private void loadstate()
        {
            //throw new NotImplementedException();
            comboBox1.Items.Add("Verginia");
        }

        private void loadaccount()
        {
            BSE = new banking_dbEntities2();
            var item = BSE.userAccounts.ToArray();
            no = item.LastOrDefault().Account_No + 1;
            accnotext.Text = Convert.ToString(no);
        }

        private void loaddate()
        {
            //throw new NotImplementedException();
            datelbl.Text = DateTime.Now.ToString("MM/dd/yyyy");
        }

        private void upphoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog opebdlg = new OpenFileDialog();
            if (opebdlg.ShowDialog() == DialogResult.OK)
            {
                Image img = Image.FromFile(opebdlg.FileName);
                pictureBox1.Image = img;
                ms = new MemoryStream();
                img.Save(ms, img.RawFormat);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (maleradio.Checked)
            {
                gender = "male";
            }
            else if (femaleradio.Checked)
            {
                gender = "female";
            }

            if (marriedradio.Checked)
            {
                m_status = "married";
            }
            else if (singleradio.Checked)
            {
                m_status = "single";
            }
            BSE = new banking_dbEntities2();
            userAccount acc = new userAccount();
            acc.Account_No = Convert.ToDecimal(accnotext.Text);
            acc.Name = nametxt.Text;
            acc.Date_of_Birth = DOB.Value.ToString();
            acc.Phone_No = phoneno.Text;
            acc.Adress = addtxt.Text;
            acc.District = disttxt.Text;
            acc.State = comboBox1.SelectedItem.ToString();
            acc.Gender = gender;
            acc.Martial_status = m_status;
            acc.Mother_Name = mothertxt.Text;
            acc.Father_Name = fathertxt.Text;
            acc.Balance = Convert.ToDecimal(balancetxt.Text);
            acc.Date = datelbl.Text;
            acc.Picture = ms.ToArray();
            BSE.userAccounts.Add(acc);
            if (String.IsNullOrEmpty(accnotext.Text) || String.IsNullOrEmpty(nametxt.Text) || String.IsNullOrEmpty(phoneno.Text) || String.IsNullOrEmpty(addtxt.Text) || String.IsNullOrEmpty(disttxt.Text) ||
                String.IsNullOrEmpty(mothertxt.Text) || String.IsNullOrEmpty(comboBox1.Text) || String.IsNullOrEmpty(fathertxt.Text) || acc.Picture == null || balancetxt.Text == string.Empty || comboBox1.SelectedIndex <= -1)
            {
                MessageBox.Show("Fill all the fields");
            }
            
            else if (acc.Balance < 0) MessageBox.Show("Incorrect balance");
            else
            {
                try
                {
                    BSE.SaveChanges();
                }
                catch (DbEntityValidationException ex)
                {
                    foreach (var eve in ex.EntityValidationErrors)
                    {
                        Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                            eve.Entry.Entity.GetType().Name, eve.Entry.State);
                        foreach (var ve in eve.ValidationErrors)
                        {
                            Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                                ve.PropertyName, ve.ErrorMessage);
                        }
                    }
                    throw;
                }
                MessageBox.Show("File saved");
            }
        }
        private void accnotext_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
