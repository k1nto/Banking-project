﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.Entity.Validation;

namespace Course_project
{
    public partial class UpdateForm : Form
    {
        banking_dbEntities2 dbe;
        MemoryStream ms;
        BindingList<userAccount> bi;



        public UpdateForm()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            bi.RemoveAt(dataGridView1.CurrentCell.RowIndex);
            dbe = new banking_dbEntities2();
            decimal a = Convert.ToDecimal(acctxt.Text);
            userAccount acc = dbe.userAccounts.First(s => s.Account_No.Equals(a));
            dbe.userAccounts.Remove(acc);
            try
            {
                dbe.SaveChanges();   
            }
            catch (DbEntityValidationException ex)
            {
                foreach (var eve in ex.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
            MessageBox.Show("Account " + acctxt.Text + " Has Duccessfully Deleted");
        }

        private void UpdateForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            bi = new BindingList<userAccount>();
            dbe = new banking_dbEntities2();
            decimal accno = Convert.ToDecimal(acctxt.Text);
            var item = dbe.userAccounts.Where(a => a.Account_No == accno);
            foreach (var item1 in item)
            {
                bi.Add(item1);
            }
            dataGridView1.DataSource = bi;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            bi = new BindingList<userAccount>();
            dbe = new banking_dbEntities2();
            var item = dbe.userAccounts.Where(a => a.Name == nametxt.Text);
            foreach (var item1 in item)
            {
                bi.Add(item1);
            }
            
            dataGridView1.DataSource = bi;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            dbe = new banking_dbEntities2();
            decimal accno = Convert.ToDecimal(dataGridView1.Rows[e.RowIndex].Cells[0].Value);
            var item = dbe.userAccounts.Where(a => a.Account_No == accno).FirstOrDefault();
            acctxt.Text = item.Account_No.ToString();
            nametxt.Text = item.Name;
            mothertxt.Text = item.Mother_Name;
            fathertxt.Text = item.Father_Name;
            phonetxt.Text = item.Phone_No;
            adresstxt.Text = item.Adress;
            byte[] img = item.Picture;
            MemoryStream ms = new MemoryStream(img);
            pictureBox1.Image = Image.FromStream(ms);
            districttxt.Text = item.District;
            statetxt.Text = item.State;
            if (item.Gender == "male")
            {
                maleradio.Checked = true;
            }
            else if (item.Gender == "female")
            {
                femaleradio.Checked = true;
            }
            if (item.Martial_status == "married")
            {
                marriedradio.Checked = true;
            }
            else if (item.Martial_status == "single")
            {
                singleradio.Checked = true;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog opendlg = new OpenFileDialog();
            if (opendlg.ShowDialog() == DialogResult.OK)
            {
                Image img = Image.FromFile(opendlg.FileName);
                pictureBox1.Image = img;
                ms = new MemoryStream();
                img.Save(ms, img.RawFormat);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dbe = new banking_dbEntities2();
            decimal accountno = Convert.ToDecimal(acctxt.Text);
            userAccount useraccount = dbe.userAccounts.First(s => s.Account_No.Equals(accountno));
            useraccount.Account_No = Convert.ToDecimal(acctxt.Text);
            useraccount.Name = nametxt.Text;
            useraccount.Date = dateTimePicker1.Value.ToString();
            useraccount.Mother_Name = mothertxt.Text;
            useraccount.Father_Name = fathertxt.Text;
            useraccount.Phone_No = phonetxt.Text;
            if (maleradio.Checked == true) useraccount.Gender = "male";
            else {if (femaleradio.Checked == true) useraccount.Gender = "female"; }
            if (marriedradio.Checked == true) useraccount.Martial_status = "married";
            else { if (singleradio.Checked == true) useraccount.Martial_status = "single"; }
            Image img = pictureBox1.Image;
            if (img.RawFormat != null)
            {
                if (ms != null)
                {
                    img.Save(ms, img.RawFormat);
                    useraccount.Picture = ms.ToArray();
                }
            }
            useraccount.Adress = adresstxt.Text;
            useraccount.District = districttxt.Text;
            useraccount.State = statetxt.Text;
            if (String.IsNullOrEmpty(acctxt.Text) || String.IsNullOrEmpty(nametxt.Text) || String.IsNullOrEmpty(mothertxt.Text) || String.IsNullOrEmpty(fathertxt.Text) || String.IsNullOrEmpty(phonetxt.Text) || pictureBox1.Image == null)
                MessageBox.Show("Fill all the fields");
            else if (dateTimePicker1.Value > DateTime.Now.Date) MessageBox.Show("Incorrect Date Of Birth");
            else
            {
                dbe.SaveChanges();
                MessageBox.Show("Information Updated");
            }
        }
    }
}
