﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_project
{
    public partial class Menu : Form
    {

        Login_Form x = new Login_Form();
        public Menu()
        {
            InitializeComponent();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void newAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void newAccountToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            newAccount newAcc = new newAccount();
            newAcc.MdiParent = this;
            newAcc.Show();
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateForm up = new UpdateForm();
            up.MdiParent = this;
            up.Show();
        }

        private void CustomerListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomerList customers = new CustomerList();
            customers.MdiParent = this;
            customers.Show();
        }

      
        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            x.Show();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangePassword cp = new ChangePassword();
            cp.MdiParent = this;
            cp.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        

        private void transferToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TransferForm trans = new TransferForm();
            trans.MdiParent = this;
            trans.Show();
        }

        

        private void depositToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            CreditForm crdfrm = new CreditForm();
            crdfrm.MdiParent = this;
            crdfrm.Show();
        }

        private void withdrawToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            WithdrawForm with = new WithdrawForm();
            with.MdiParent = this;
            with.Show();
        }
    }
}
