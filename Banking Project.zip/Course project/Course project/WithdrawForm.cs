﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity.Validation;

namespace Course_project
{
    public partial class WithdrawForm : Form
    {
        public WithdrawForm()
        {
            InitializeComponent();
        }

        private void accnotxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            banking_dbEntities2 context = new banking_dbEntities2();
            decimal b = Convert.ToDecimal(acctxt.Text);
            var item = (from u in context.userAccounts where u.Account_No == b select u).FirstOrDefault();
            nametxt.Text = item.Name;
            oldbaltxt.Text = Convert.ToString(item.Balance);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            banking_dbEntities2 context = new banking_dbEntities2();
            newAccount acc = new newAccount();
            Withdraw dp = new Withdraw();
            dp.Date = datelbl.Text;
            dp.AccountNo = Convert.ToDecimal(acctxt.Text);
            dp.Name = nametxt.Text;
            dp.OldBalance = Convert.ToDecimal(oldbaltxt.Text);
            dp.WithAmount = Convert.ToDecimal(amounttxt.Text);
            if (String.IsNullOrEmpty(acctxt.Text) || String.IsNullOrEmpty(nametxt.Text) || String.IsNullOrEmpty(oldbaltxt.Text) || String.IsNullOrEmpty(amounttxt.Text))
                MessageBox.Show("Fill all the fields");
            else
            {
                context.Withdraws.Add(dp);
                try
                {
                    context.SaveChanges();
                }
                catch (DbEntityValidationException ex)
                {
                    foreach (var eve in ex.EntityValidationErrors)
                    {
                        Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                            eve.Entry.Entity.GetType().Name, eve.Entry.State);
                        foreach (var ve in eve.ValidationErrors)
                        {
                            Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                                ve.PropertyName, ve.ErrorMessage);
                        }
                    }
                    throw;
                }
                decimal b = Convert.ToDecimal(acctxt.Text);
                var item = (from u in context.userAccounts where u.Account_No == b select u).FirstOrDefault();
                if (dp.OldBalance > dp.WithAmount)
                {
                    item.Balance = item.Balance - Convert.ToDecimal(amounttxt.Text);
                    try
                    {
                        context.SaveChanges();
                    }
                    catch (DbEntityValidationException ex)
                    {
                        foreach (var eve in ex.EntityValidationErrors)
                        {
                            Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                                eve.Entry.Entity.GetType().Name, eve.Entry.State);
                            foreach (var ve in eve.ValidationErrors)
                            {
                                Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                                    ve.PropertyName, ve.ErrorMessage);
                            }
                        }
                        throw;
                    }
                    MessageBox.Show("Withdraw Money Has Been Done Successfully. Current Balance: " + item.Balance);
                }
                else MessageBox.Show("Not Enough Money To Withdraw");
            }
        }

        
    }
}
