﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_project
{
    public partial class TransferForm : Form
    {
        public TransferForm()
        {
            InitializeComponent();
        }

        private void detailsbutton_Click(object sender, EventArgs e)
        {
            banking_dbEntities2 dbe = new banking_dbEntities2();
            decimal b = Convert.ToDecimal(fromacctxt.Text);
            var item = (from u in dbe.userAccounts where u.Account_No == b select u).FirstOrDefault();
            nametxt.Text = item.Name;
            amounttxt.Text = Convert.ToString(item.Balance);
        }

        private void transferbutton_Click(object sender, EventArgs e)
        {
            banking_dbEntities2 dbe = new banking_dbEntities2();
            decimal b = Convert.ToDecimal(fromacctxt.Text);
            var item = (from u in dbe.userAccounts where u.Account_No == b select u).FirstOrDefault();
            decimal b1 = Convert.ToDecimal(item.Balance);
            decimal totalbal = Convert.ToDecimal(transfertxt.Text);
            decimal transferacc = Convert.ToDecimal(desaccounttxt.Text);
            if (b1 > totalbal)
            {
                userAccount item2 = (from u in dbe.userAccounts where u.Account_No == transferacc select u).FirstOrDefault();
                item2.Balance = item2.Balance + totalbal;
                item.Balance = item.Balance - totalbal;
                //dbe.SaveChanges();
                Transfer1 transfer = new Transfer1();
                transfer.Account_No = Convert.ToDecimal(fromacctxt.Text);
                transfer.ToTransfer = Convert.ToDecimal(desaccounttxt.Text);
                transfer.Date = DateTime.UtcNow.ToString();
                transfer.Name = nametxt.Text;
                transfer.balance = Convert.ToDecimal(transfertxt.Text);
                if (String.IsNullOrEmpty(fromacctxt.Text) || String.IsNullOrEmpty(desaccounttxt.Text) || String.IsNullOrEmpty(nametxt.Text) || String.IsNullOrEmpty(transfertxt.Text))
                    MessageBox.Show("Fill all the fields");
                else
                {
                    dbe.Transfer1.Add(transfer);
                    dbe.SaveChanges();
                }
                MessageBox.Show("Done");
            }
            else MessageBox.Show("Not Enough Money To Transfer");
        }
    }
}
