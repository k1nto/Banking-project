﻿
namespace Course_project
{
    partial class newAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.datelbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.Martial_Status = new System.Windows.Forms.GroupBox();
            this.singleradio = new System.Windows.Forms.RadioButton();
            this.marriedradio = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.femaleradio = new System.Windows.Forms.RadioButton();
            this.maleradio = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.upphoto = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.phoneno = new System.Windows.Forms.TextBox();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.accnotext = new System.Windows.Forms.TextBox();
            this.addtxt = new System.Windows.Forms.TextBox();
            this.disttxt = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.DOB = new System.Windows.Forms.DateTimePicker();
            this.mothertxt = new System.Windows.Forms.TextBox();
            this.fathertxt = new System.Windows.Forms.TextBox();
            this.balancetxt = new System.Windows.Forms.TextBox();
            this.Martial_Status.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(319, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(226, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Customer Information Form";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(359, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Current date:";
            // 
            // datelbl
            // 
            this.datelbl.AutoSize = true;
            this.datelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.datelbl.Location = new System.Drawing.Point(439, 70);
            this.datelbl.Name = "datelbl";
            this.datelbl.Size = new System.Drawing.Size(52, 13);
            this.datelbl.TabIndex = 2;
            this.datelbl.Text = "Datalabel";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(12, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 15);
            this.label4.TabIndex = 3;
            this.label4.Text = "Account No.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(12, 163);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(12, 206);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 15);
            this.label6.TabIndex = 5;
            this.label6.Text = "Date of Birth";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(12, 245);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "Phone Number";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(12, 279);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 15);
            this.label8.TabIndex = 7;
            this.label8.Text = "Adress";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(12, 351);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 15);
            this.label9.TabIndex = 8;
            this.label9.Text = "Dist.";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(12, 392);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 15);
            this.label10.TabIndex = 9;
            this.label10.Text = "State";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(532, 451);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "Mother\'s Name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(532, 488);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 13);
            this.label13.TabIndex = 12;
            this.label13.Text = "Father\'s Name";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(532, 525);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 13);
            this.label14.TabIndex = 13;
            this.label14.Text = "Balance";
            // 
            // Martial_Status
            // 
            this.Martial_Status.Controls.Add(this.singleradio);
            this.Martial_Status.Controls.Add(this.marriedradio);
            this.Martial_Status.Location = new System.Drawing.Point(529, 332);
            this.Martial_Status.Name = "Martial_Status";
            this.Martial_Status.Size = new System.Drawing.Size(324, 52);
            this.Martial_Status.TabIndex = 14;
            this.Martial_Status.TabStop = false;
            this.Martial_Status.Text = "Marital status";
            // 
            // singleradio
            // 
            this.singleradio.AutoSize = true;
            this.singleradio.Location = new System.Drawing.Point(92, 19);
            this.singleradio.Name = "singleradio";
            this.singleradio.Size = new System.Drawing.Size(54, 17);
            this.singleradio.TabIndex = 1;
            this.singleradio.TabStop = true;
            this.singleradio.Text = "Single";
            this.singleradio.UseVisualStyleBackColor = true;
            // 
            // marriedradio
            // 
            this.marriedradio.AutoSize = true;
            this.marriedradio.Location = new System.Drawing.Point(6, 19);
            this.marriedradio.Name = "marriedradio";
            this.marriedradio.Size = new System.Drawing.Size(60, 17);
            this.marriedradio.TabIndex = 0;
            this.marriedradio.TabStop = true;
            this.marriedradio.Text = "Married";
            this.marriedradio.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.femaleradio);
            this.groupBox2.Controls.Add(this.maleradio);
            this.groupBox2.Location = new System.Drawing.Point(529, 206);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(324, 52);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Gender";
            // 
            // femaleradio
            // 
            this.femaleradio.AutoSize = true;
            this.femaleradio.Location = new System.Drawing.Point(87, 19);
            this.femaleradio.Name = "femaleradio";
            this.femaleradio.Size = new System.Drawing.Size(59, 17);
            this.femaleradio.TabIndex = 1;
            this.femaleradio.TabStop = true;
            this.femaleradio.Text = "Female";
            this.femaleradio.UseVisualStyleBackColor = true;
            // 
            // maleradio
            // 
            this.maleradio.AutoSize = true;
            this.maleradio.Location = new System.Drawing.Point(6, 19);
            this.maleradio.Name = "maleradio";
            this.maleradio.Size = new System.Drawing.Size(48, 17);
            this.maleradio.TabIndex = 0;
            this.maleradio.TabStop = true;
            this.maleradio.Text = "Male";
            this.maleradio.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(591, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(218, 152);
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // upphoto
            // 
            this.upphoto.Location = new System.Drawing.Point(637, 176);
            this.upphoto.Name = "upphoto";
            this.upphoto.Size = new System.Drawing.Size(127, 24);
            this.upphoto.TabIndex = 17;
            this.upphoto.Text = "Upload Photo";
            this.upphoto.UseVisualStyleBackColor = true;
            this.upphoto.Click += new System.EventHandler(this.upphoto_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(235, 469);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(127, 32);
            this.button2.TabIndex = 18;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // phoneno
            // 
            this.phoneno.Location = new System.Drawing.Point(109, 244);
            this.phoneno.Name = "phoneno";
            this.phoneno.Size = new System.Drawing.Size(263, 20);
            this.phoneno.TabIndex = 19;
            // 
            // nametxt
            // 
            this.nametxt.Location = new System.Drawing.Point(109, 162);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(263, 20);
            this.nametxt.TabIndex = 21;
            // 
            // accnotext
            // 
            this.accnotext.Location = new System.Drawing.Point(109, 118);
            this.accnotext.Name = "accnotext";
            this.accnotext.ReadOnly = true;
            this.accnotext.Size = new System.Drawing.Size(263, 20);
            this.accnotext.TabIndex = 22;
            this.accnotext.TextChanged += new System.EventHandler(this.accnotext_TextChanged);
            // 
            // addtxt
            // 
            this.addtxt.Location = new System.Drawing.Point(109, 276);
            this.addtxt.Multiline = true;
            this.addtxt.Name = "addtxt";
            this.addtxt.Size = new System.Drawing.Size(263, 50);
            this.addtxt.TabIndex = 23;
            // 
            // disttxt
            // 
            this.disttxt.Location = new System.Drawing.Point(109, 348);
            this.disttxt.Name = "disttxt";
            this.disttxt.Size = new System.Drawing.Size(263, 20);
            this.disttxt.TabIndex = 24;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(109, 389);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(263, 21);
            this.comboBox1.TabIndex = 25;
            // 
            // DOB
            // 
            this.DOB.Location = new System.Drawing.Point(109, 206);
            this.DOB.Name = "DOB";
            this.DOB.Size = new System.Drawing.Size(263, 20);
            this.DOB.TabIndex = 26;
            // 
            // mothertxt
            // 
            this.mothertxt.Location = new System.Drawing.Point(616, 448);
            this.mothertxt.Name = "mothertxt";
            this.mothertxt.Size = new System.Drawing.Size(237, 20);
            this.mothertxt.TabIndex = 27;
            // 
            // fathertxt
            // 
            this.fathertxt.Location = new System.Drawing.Point(616, 485);
            this.fathertxt.Name = "fathertxt";
            this.fathertxt.Size = new System.Drawing.Size(237, 20);
            this.fathertxt.TabIndex = 28;
            // 
            // balancetxt
            // 
            this.balancetxt.Location = new System.Drawing.Point(616, 522);
            this.balancetxt.Name = "balancetxt";
            this.balancetxt.Size = new System.Drawing.Size(237, 20);
            this.balancetxt.TabIndex = 29;
            this.balancetxt.Text = "0";
            // 
            // newAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(899, 620);
            this.Controls.Add(this.balancetxt);
            this.Controls.Add(this.fathertxt);
            this.Controls.Add(this.mothertxt);
            this.Controls.Add(this.DOB);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.disttxt);
            this.Controls.Add(this.addtxt);
            this.Controls.Add(this.accnotext);
            this.Controls.Add(this.nametxt);
            this.Controls.Add(this.phoneno);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.upphoto);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.Martial_Status);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.datelbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "newAccount";
            this.Text = "newAccount";
            this.Martial_Status.ResumeLayout(false);
            this.Martial_Status.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label datelbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox Martial_Status;
        private System.Windows.Forms.RadioButton singleradio;
        private System.Windows.Forms.RadioButton marriedradio;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton femaleradio;
        private System.Windows.Forms.RadioButton maleradio;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button upphoto;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox phoneno;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.TextBox accnotext;
        private System.Windows.Forms.TextBox addtxt;
        private System.Windows.Forms.TextBox disttxt;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.DateTimePicker DOB;
        private System.Windows.Forms.TextBox mothertxt;
        private System.Windows.Forms.TextBox fathertxt;
        private System.Windows.Forms.TextBox balancetxt;
    }
}