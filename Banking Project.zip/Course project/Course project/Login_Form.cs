﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Course_project
{
    public partial class Login_Form : Form
    {
        
        public Login_Form()
        {
            InitializeComponent();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
           
        }
                                                                                                                  
        private void Button1_Click(object sender, EventArgs e)
        {
            banking_dbEntities2 dbe = new banking_dbEntities2();
            if (user.Text != string.Empty || pass.Text != string.Empty)
            {
                var user1 = dbe.Admin_Table.FirstOrDefault(a => a.Username.Equals(user.Text));
                if (user1!=null)
                {
                    if (user1.Password.Equals(pass.Text))
                    {
                        this.Hide();
                        Menu m1 = new Menu();
                        m1.ShowDialog();
                    }
                    else 
                    {
                        MessageBox.Show("Password incorrect");
                    }
                }
                else
                {
                    MessageBox.Show("Null Value");
                }
            }
  
            else
            {
                MessageBox.Show("Please, enter username and password");
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        /*private void label2_Click(object sender, EventArgs e)
        {

        }*/
    }
}
