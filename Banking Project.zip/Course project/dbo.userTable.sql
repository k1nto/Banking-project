﻿CREATE TABLE [dbo].[userAccount] 
(
    [Account_No] DECIMAL NOT NULL PRIMARY KEY, 
    [Name] NVARCHAR(50) NULL, 
    [Date of Birth] NVARCHAR(50) NULL, 
    [Phone_No] NCHAR(10) NULL, 
    [Adress] NVARCHAR(MAX) NULL, 
    [District] NVARCHAR(50) NULL, 
    [State] NVARCHAR(50) NULL, 
    [Picture] IMAGE NULL, 
    [Gender] NVARCHAR(50) NULL, 
    [Martial_status] NVARCHAR(50) NULL, 
    [Mother_Name] NVARCHAR(50) NULL, 
    [Father_Name] NVARCHAR(50) NULL, 
    [Balance] DECIMAL NULL
);

